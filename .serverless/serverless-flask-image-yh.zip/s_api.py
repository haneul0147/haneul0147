import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='sky0147',
    application_name='serverless-flask-image-yh',
    app_uid='D4tz9LtsqYZD2q5RHj',
    org_uid='e7c07ece-face-462a-8e99-8290308687a3',
    deployment_uid='32b52f82-1fde-435a-af6a-640a0037b39f',
    service_name='serverless-flask-image-yh',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-image-yh-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
